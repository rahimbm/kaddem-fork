package tn.esprit.spring.khaddemmaramarfaoui.enties;

public enum Option {
    SE,GAMIX,SIM,NIDS;
}
