package tn.esprit.spring.khaddemmaramarfaoui.enties;

public enum Specialte {
    IA,RESEAUX,CLOUD,SECURITE;
}
