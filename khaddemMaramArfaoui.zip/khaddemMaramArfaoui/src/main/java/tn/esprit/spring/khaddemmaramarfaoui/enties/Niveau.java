package tn.esprit.spring.khaddemmaramarfaoui.enties;

public enum Niveau {
  JUNIOR,SENIOR,EXPERT;
}
