package tn.esprit.spring.khaddemmaramarfaoui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KhaddemMaramArfaouiApplication {

    public static void main(String[] args) {
        SpringApplication.run(KhaddemMaramArfaouiApplication.class, args);
    }

}
